const express = require ('express');
const cors = require ('cors');
const bodyParser = require ('body-parser');
const mysql = require ('mysql');
const uuid = require ('uuid');
const session = require ('express-session');

const con = mysql.createConnection({
    host: 'localhost',
    port:3306,
    user: 'root',
    password: '1234',
    database: 'meubanco'
})

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.get('/', (req,res) => {
    res.sendFile(path.join(__dirname, './public', 'index.html'));
})


app.post('/usuarios/cadastro', (req,res) => {
    const id = uuid.v4();
    let { email, senha, nome } = req.body;
    //console.log(email, senha, nome);
    con.query(`INSERT INTO usuarios (id_usuario,  nome_usuario, email_usuario, senha)
    VALUES ("${id}", "${nome}","${email}", "${senha}")`,(err,result)=>{
        if(err) throw err;
        res.json('ok');
    }
    );
})

app.post('/usuarios/autentica',(req,res) => {
    let { email,senha } = req.body;
    console.log(email,senha);
    con.query( `SELECT id_usuario FROM
    usuarios WHERE email_usuario= "${email}" AND senha="${senha}"`, (err,result) => {
        if(err) throw err;
        console.log(result);
        res.json("ok");
    });
})


app.listen(38000,() => {
    console.log ('Servidor Ligado');
})
