import React, { useState } from 'react';
import { Container, Input, Button, Title } from './styles'
import { NOMEM } from 'dns';

export default function Cadastro() {

  const [email, setEmail] = useState(null);
  const [senha, setSenha] = useState(null);
  const [nome, setNome] = useState(null);
  const [EhCadastro, setEhCadastro] = useState(false);

  const cadastro = async () => {
    const json = JSON.stringify({
      nome: nome,
      senha: senha,
      email: email
    })
    const data = await fetch("http://localhost:38000/usuarios/cadastro", {
      method: "POST",
      headers: {
        "content-type": "application/json"
      },
      body: json
    })
  
    const resposta = await data.json()
    console.log(resposta);
  }
    const login = async () => {
      const json = JSON.stringify({
        email: email,
        senha: senha
      })
      const data = await fetch("http://localhost:38000/usuarios/autentica", {
        method: "POST",
        headers: {
          "content-type": "application/json"
        },
        body: json
      })
      const resposta = await data.json()
      console.log(resposta);
     
    }  


    
    

  let campoNome = <Input type="text" name="name" placeholder="Digite seu nome"
    value={nome} onChange={e => setNome(e.target.value)}
  />

  return (
    <Container>
      <Title>Faça seu {EhCadastro ?  "Cadastro": "Login"}</Title>
      {EhCadastro ? campoNome : ""}

      <Input type="email" placeholder="Digite seu email"
        value={email} onChange={e => setEmail(e.target.value)}
      />
      <Input type="password" placeholder="Informe sua senha"
        value={senha} onChange={e => setSenha(e.target.value)}
      />
      <Button type="submit" onClick={EhCadastro ? cadastro :login }> Entrar </Button>
      <Button primary onClick={e => setEhCadastro(!EhCadastro)}>{EhCadastro ?  ("Logar-se") : ("Cadastre-se") }</Button>
    </Container>
  );
}