import React, {useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Link } from 'react-router-dom'

function Formulario() {
const [email,setEmail]=useState('');
const [senha,setSenha]=useState('');
const [nome,setNome]=useState('');
const [ehCadastro,setEhcadastro]=useState(true);

const Logar = async () =>{
const response=await fetch(`http://localhost:38000/usuarios/cadastro`,
{
method :'POST',
headers:{
'Content-type' : 'application/json'
},
body:JSON.stringify(nome,email,senha)
});
// const data= await response.json();
// console.log(data);
}
let campoNome = ehCadastro ? <div className="form-group">
<label htmlFor="InputName">Nome:</label>
<input type="text" onChange={text=>setNome(text.target.value)} className="form-control" id="InputName" />
</div> : '';
return (
<div className="Formulario">
<div className="jumbotron">
<h1 className="display-5">{ehCadastro ? "Cadastro" : "Login"}</h1>
</div>
<div className="container">
<form >
{campoNome}
<div className="form-group">
<label htmlFor="InputEmail">Email:</label>
<input type="email" onChange={text=>setEmail(text.target.value)} className="form-control" id="InputEmail" aria-describedby="emailHelp" />
</div>
<div className="form-group">
<label htmlFor="InputPassword">Senha:</label>
<input type="password" onChange={text=>setSenha(text.target.value)} className="form-control" id="InputPassword" />
</div>
<button type="button" onClick={Logar} className="btn btn-primary btn-lg btn-block">{ehCadastro ? "Cadastrar" : "Logar"}</button>
<br />
<button type="button" onClick={e=>setEhcadastro(!ehCadastro)} className="btn btn-secondary btn-lg btn-block">Ir para {ehCadastro ? "Login" : "Cadastro"}</button>
</form>
</div> 
</div>
);
}

export default Formulario;