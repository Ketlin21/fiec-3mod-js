import React from 'react'

export default function Rifa() {
    return (
        <div>
            <h1>Olá rifa</h1>
        </div>
    )
}
