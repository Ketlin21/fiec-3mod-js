import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';


function Login() {

const [email,setEmail]=useState('');
const [senha,setSenha]=useState('');
const Logar = async event => {
event.preventDefault();
console.log(email,senha)
    }

  return (
    <div className="App">
    <div className="jumbotron">
  <h1>Login</h1>
    </div>
    <div className="container">
    <form>
  <div className="form-group">
    <label htmlFor="exampleInputEmail1">Email </label>
    <input type="email" onChange={text=>setEmail(text.target.value)} className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"/>
 
  </div>
  <div className="form-group">
<label htmlFor="InputPassword">Senha:</label>
<input type="password" onChange={text=>setSenha(text.target.value)} className="form-control" id="InputPassword" />
</div>
<button type="button" onClick={Logar} className="btn btn-primary btn-lg btn-block">{ehCadastro ? "Cadastrar" : "Logar"}</button>
<br />
<button type="button" onClick={e=>setEhcadastro(!ehCadastro)} className="btn btn-secondary btn-lg btn-block">Ir para {ehCadastro ? "Login" : "Cadastro"}</button>

</form>
</div> 
</div>
);
}

export default Login;