import React,{useState} from 'react';
import {BrowserRouter, Switch, Route} from 'react-router-dom';

//Importar as páginas
import Cadastro from "./Cadastro"
import Home from './Home';


//Criar o componentes com as rotas
const App=()=>{
const [logado,setLogado] = useState (false);
return(
<Switch>
{logado ?
<Route path="/" exact > <Home logar={setLogado}/></Route>
:
<Route path="/" exact > <Cadastro logar={setLogado}/></Route>
}
</Switch>
);
};

export default App;
