<?php


$db = new PDO('mysql:host=localhost:3308;dbname=lojinha', 'root', '');
